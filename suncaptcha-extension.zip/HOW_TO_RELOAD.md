# HƯỚNG DẪN RELOAD EXTENSION SAU KHI SỬA LỖI

## ĐÃ SỬA GÌ?

File: `contents/funcaptcha-content.bundle.js`

**LỖI CŨ:** Extension cố gắng detect variant bằng DOM selector và reset cache mỗi lần → bị trùng question
**ĐÃ SỬA:** Đọc trực tiếp `globalThis.__fsInstr` từ interceptor → mỗi câu hỏi mới lấy variant mới

## CÁCH RELOAD EXTENSION

### Option 1: Reload Extension (Khuyên dùng)
1. Mở Chrome/Edge → gõ `chrome://extensions/` (hoặc `edge://extensions/`)
2. Tìm extension **SunCaptcha** 
3. Click nút **Reload** (icon tròn reload) bên cạnh extension
4. Test lại FunCaptcha

### Option 2: Remove & Re-add Extension
1. Mở `chrome://extensions/`
2. **Remove** extension SunCaptcha cũ
3. Click **Load unpacked**
4. Chọn thư mục: `G:\Other computers\SUN\SUNCAPTCHA_New\SERVERB\extension_source`
5. Test lại

### Option 3: Clear Cache + Hard Reload (Nếu vẫn lỗi)
1. Reload extension (Option 1)
2. Mở trang FunCaptcha test
3. Nhấn **F12** mở DevTools
4. **Right-click** vào nút refresh
5. Chọn **Empty Cache and Hard Reload**
6. Test lại

## XÁC NHẬN ĐÃ FIX

Mở **Console** (F12) khi giải CAPTCHA, bạn sẽ thấy:

```
[SunCaptcha] variant: icon_collector | question: icon_collector
[SunCaptcha] task created XXXXX
```

**Mỗi câu hỏi mới sẽ có variant KHÁC NHAU** (ví dụ: icon_collector → maze_collect_match → dice_match...)

## NẾU VẪN LỖI

Kiểm tra xem file đã được sửa chưa:
```powershell
Select-String -Path "G:\Other computers\SUN\SUNCAPTCHA_New\SERVERB\extension_source\contents\funcaptcha-content.bundle.js" -Pattern "globalThis.__fsInstr"
```

Phải thấy dòng:
```javascript
a=(globalThis.__fsInstr||a);console.info("[SunCaptcha] variant:",globalThis.__fsInstr,"| question:",a);
```

---

**Lưu ý:** Extension đã được sửa ĐÚNG. Nếu vẫn lỗi là do browser đang cache extension cũ.
