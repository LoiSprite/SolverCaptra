/*
 * FunCaptcha variant interceptor (MAIN world) for the farmsync solver extension.
 *
 * Arkose's real dataset name is exposed as `game_variant` or, on Roblox, as
 * `round_config.instruction_string` (e.g. "icon_collector", "dance_floor",
 * "hopscotchv2") — NOT the human prompt. Several variants share the same prompt
 * AND image size (icon_collector vs dance_floor are both 1000x400), so the
 * variant key is the ONLY reliable router signal. It arrives in /fc/ca/ every
 * wave. The most robust catch is the JSON.parse hook: Arkose JSON-parses its
 * game config in the frame even when the raw network response is encrypted.
 *
 * Emits the variant via the `__fs_instr` CustomEvent the solver consumes.
 * Every hook is wrapped in try/catch and returns the original result untouched.
 */
(() => {
  "use strict";

  // The solver bundle reads `globalThis.__fsInstr`, but it runs in the
  // match-game-ui CHILD frame while wave 1's variant arrives via /fc/gfct/ in
  // the same-origin ENFORCEMENT parent frame — different globals. We store the
  // variant on a plain window property per frame, and expose __fsInstr as a
  // GETTER that walks up same-origin parent frames. So when the bundle (child)
  // reads __fsInstr, it transparently pulls the variant the parent caught,
  // synchronously at read time — no event, no storage, no timing race. The
  // setter still records this frame's own value (for /fc/ca/ caught locally).
  const STORE = '__fsVariantStore';
  const readVariant = () => {
    // 1. this frame's stored value, then same-origin parents.
    try {
      let w = window;
      for (let i = 0; i < 6; i++) {
        try { if (w[STORE]) return w[STORE]; } catch (_) { break; } // cross-origin parent → stop
        if (w === w.parent) break;
        w = w.parent;
      }
    } catch (_) {}
    // 2. SAME-FRAME DOM fallback: the example/key images in the game frame are
    //    served from .../game4failureexamples/<variant>/... — the variant is
    //    literally in the URL, right here in the frame the solver runs in.
    try {
      const els = document.querySelectorAll('img[src*="ailureexamples"]');
      for (let i = 0; i < els.length; i++) {
        const m = /ailureexamples\/([a-z0-9_]{3,40})\//i.exec(els[i].src || '');
        if (m) return m[1].toLowerCase();
      }
    } catch (_) {}
    return '';
  };
  try {
    Object.defineProperty(globalThis, '__fsInstr', {
      configurable: true,
      get() { return readVariant(); },
      set(v) { try { const f = String(v || '').toLowerCase(); if (f) window[STORE] = f; } catch (_) {} },
    });
  } catch (_) {}
  const emit = (v) => {
    const folder = String(v).toLowerCase();
    try { window[STORE] = folder; } catch (_) {}
    try {
      document.dispatchEvent(new CustomEvent('__fs_instr', { detail: String(v) }));
    } catch (_) {}
  };

  // Raw Arkose variant signal — prefer game_variant, then instruction_string.
  const deepFindRaw = (obj, depth) => {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return null;
      if (typeof obj.game_variant === 'string' && obj.game_variant) return obj.game_variant;
      if (typeof obj.instruction_string === 'string' && obj.instruction_string) return obj.instruction_string;
      for (const k in obj) {
        if (!Object.prototype.hasOwnProperty.call(obj, k)) continue;
        const v = obj[k];
        if (v && typeof v === 'object') {
          const found = deepFindRaw(v, (depth || 0) + 1);
          if (found) return found;
        }
      }
      return null;
    } catch (_) { return null; }
  };

  // Keep the raw signal as the category, stripping only chars the server rejects.
  const normalizeVariant = (raw) => {
    if (!raw) return null;
    const s = String(raw).replace(/[^A-Za-z0-9_-]/g, '');
    return s || null;
  };

  // The variant can differ per wave, so ALWAYS emit the current one (the solver
  // uses the latest for the wave it's solving). Redundant same-variant emits are
  // harmless; only the log is deduped to avoid console spam.
  let lastLogged = null;
  const publish = (raw) => {
    try {
      // The variant is a short token (icon_collector, dance_floor). The same
      // field can also carry the human PROMPT ("Use the arrows to ...") on the
      // /fc/gfct/ endpoint — reject anything with whitespace so we never send a
      // sentence as a category.
      if (/\s/.test(String(raw))) return;
      const folder = normalizeVariant(raw);
      if (!folder) return;
      if (folder !== lastLogged) {
        lastLogged = folder;
        try { console.log('[farmsync] variant:', raw, '->', folder); } catch (_) {}
      }
      emit(folder);
    } catch (_) {}
  };

  const inspectObject = (obj) => {
    try {
      const v = deepFindRaw(obj, 0);
      if (v) { publish(v); return true; }
      return false;
    } catch (_) { return false; }
  };

  const inspectText = (text, url) => {
    try {
      if (!text || typeof text !== 'string') return false;
      const relevant = text.indexOf('game_variant') !== -1 ||
                       text.indexOf('instruction_string') !== -1 ||
                       text.indexOf('round_config') !== -1;
      if (!relevant && !(url && /gfct|\/fc\/ca|\/fc\/gc/i.test(url))) return false;
      return inspectObject(JSON.parse(text));
    } catch (_) { return false; }
  };

  // --- postMessage hook: the game CHILD frame receives its config (carrying
  // the variant) via postMessage from the enforcement frame. Catch it HERE, in
  // the same frame the solver bundle runs in, so wave 1 has it with no
  // cross-frame read at all. ---
  try {
    window.addEventListener('message', (e) => {
      try {
        const d = e && e.data;
        if (!d) return;
        if (typeof d === 'string') inspectText(d, '__msg__');
        else if (typeof d === 'object') inspectObject(d);
      } catch (_) {}
    }, true);
  } catch (_) {}

  // --- JSON.parse hook (most reliable; survives encrypted network responses) ---
  try {
    const origParse = JSON.parse;
    JSON.parse = function (text) {
      const result = origParse.apply(this, arguments);
      try {
        if (typeof text === 'string' &&
            (text.indexOf('game_variant') !== -1 || text.indexOf('instruction_string') !== -1)) {
          const v = deepFindRaw(result, 0);
          if (v) publish(v);
        }
      } catch (_) {}
      return result;
    };
  } catch (_) {}

  // --- fetch hook ---
  try {
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function () {
        const p = origFetch.apply(this, arguments);
        try {
          const reqUrl = arguments[0] && (typeof arguments[0] === 'string' ? arguments[0] : arguments[0].url);
          p.then((res) => {
            try { res.clone().text().then((t) => inspectText(t, reqUrl || (res && res.url)), () => {}); } catch (_) {}
            return res;
          }).catch(() => {});
        } catch (_) {}
        return p;
      };
    }
  } catch (_) {}

  // --- XHR hook ---
  try {
    const XHR = window.XMLHttpRequest;
    if (XHR && XHR.prototype) {
      const origSend = XHR.prototype.send;
      XHR.prototype.send = function () {
        try {
          this.addEventListener('load', function () {
            try {
              const url = this.responseURL || '';
              const rt = this.responseType;
              if (rt === 'json') inspectObject(this.response);
              else if (rt === '' || rt === 'text') inspectText(this.responseText, url);
            } catch (_) {}
          });
        } catch (_) {}
        return origSend.apply(this, arguments);
      };
    }
  } catch (_) {}

  const relevantUrl = (u) => u && /gfct|\/fc\/ca|\/fc\/gc/i.test(String(u));

  // --- SYNCHRONOUS response-read hooks (fixes the first-wave race) ---
  // The async load/.then handlers above can run a beat AFTER the extension has
  // already read the body and fired the first solve, so wave 1 falls back to the
  // prompt. These hooks capture the variant the instant the extension *reads* the
  // response (responseText/response getter, or Response.json/text) — which it must
  // do to get the tile image, BEFORE it solves — so __fsInstr is set in time.
  try {
    const XP = XMLHttpRequest.prototype;
    ['responseText', 'response'].forEach((prop) => {
      const d = Object.getOwnPropertyDescriptor(XP, prop);
      if (d && d.get) {
        Object.defineProperty(XP, prop, {
          configurable: true, enumerable: d.enumerable,
          get: function () {
            const val = d.get.call(this);
            try {
              if (relevantUrl(this.responseURL)) {
                if (typeof val === 'string') inspectText(val, this.responseURL);
                else if (val && typeof val === 'object') inspectObject(val);
              }
            } catch (_) {}
            return val;
          }
        });
      }
    });
  } catch (_) {}

  try {
    const RP = Response.prototype;
    const origJson = RP.json;
    RP.json = function () {
      const p = origJson.apply(this, arguments);
      try { if (relevantUrl(this.url)) p.then((o) => { try { inspectObject(o); } catch (_) {} }, () => {}); } catch (_) {}
      return p;
    };
    const origText = RP.text;
    RP.text = function () {
      const p = origText.apply(this, arguments);
      try { if (relevantUrl(this.url)) p.then((t) => { try { inspectText(t, this.url); } catch (_) {} }, () => {}); } catch (_) {}
      return p;
    };
  } catch (_) {}
})();
